## Unit 1 (HTML/CSS) - Complete video guide

### Key activities from the week

#### Lesson 1.1 ~ My First HTML

Learn to make an HTML page!
[Watch the Video!](https://www.youtube.com/watch?v=ieb6Svbc10E)

#### Lesson 1.2 ~ Student Bio Layout

Learn how to make a basic layout in CSS.
[Watch the Video!](https://www.youtube.com/watch?v=kMBinXTCrXI)

#### Lesson 1.3 ~ Floats in CSS

Learn how floats and other CSS properties work.
[Watch the Video!](https://www.youtube.com/watch?v=0lpxKw6E90Y)

#### Lesson 1.3 ~ Positioning in CSS

Learn about the positioning property in CSS.
[Watch the Video!](https://www.youtube.com/watch?v=sHfJn0jqBro)

#### Lesson 1.3 ~ CSS Positioning Layout

Learn to use positioning in a website layout.
[Watch the Video!](https://www.youtube.com/watch?v=yWXgnQaWSW0)
