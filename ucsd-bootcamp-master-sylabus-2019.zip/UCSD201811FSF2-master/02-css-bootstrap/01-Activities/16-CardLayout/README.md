### File

* *None*

### Instructions

* Working in pairs and using Twitter Bootstrap make a page that looks like the following image:

<<<<<<< HEAD
  ![Card-layout design](Solved/card-layout.png)
=======
  ![Card-layout design](card-layout.png)
>>>>>>> 9bbfaa9841f879ed3ac47bb2292a36940a11e696

* Be sure to note the:
  * Grid Layout
  * Navbar
  * Sidebar card
  * Thumbnail
