# Floats Box

## Video Solution

* Link: <https://youtu.be/mRCPM3d9jI4>
