# Slideshow

## File

* [`slideshow`](Unsolved/slideshow.js)

## Instructions

* Create a slideshow using jQuery and JavaScript Timing Events.

* Feel free to find your own images or use the ones provided in the images directory.

* Display the "loading.gif" image in between each picture for one second.

* **BONUS:** Add CSS styling.
