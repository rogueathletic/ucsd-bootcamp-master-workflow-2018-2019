# Coin Flip

## File

* [`coin-flip`](Unsolved/coin-flip.html)

## Instructions

* Make a Coin Flipper game.

* Follow the directions in the html file.

* How the app works:

  * The user chooses Heads or Tails, and the computer randomly selects heads or tails and displays the outcome on the screen. The app then displays whether or not the user won or lost.

  * If heads, use: <http://random-ize.com/coin-flip/us-quarter/us-quarter-front.jpg>

  * If tails, display: <http://random-ize.com/coin-flip/us-quarter/us-quarter-back.jpg>

* **BONUS:**

  * Put your JavaScript in its own file and link to it in the HTML.

  * Keep track of the number of Heads or Tails and display the results on the screen.

  * Add CSS styling.
