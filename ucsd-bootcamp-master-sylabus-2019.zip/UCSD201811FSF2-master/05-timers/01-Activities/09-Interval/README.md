# Simple Timer

## File

* [`interval-unsolved`](Unsolved/interval-unsolved.html)

## Instructions

* There is a small bug in this code. With a partner try and see what is wrong.

* Explain to each other what is happening in this file.
