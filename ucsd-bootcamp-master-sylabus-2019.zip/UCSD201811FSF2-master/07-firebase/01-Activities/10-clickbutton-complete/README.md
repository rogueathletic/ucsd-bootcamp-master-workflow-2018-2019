# Click Button (comments)

## File

* [`instructor-do-clickbutton-nocomments`](Unsolved/instructor-do-clickbutton-nocomments.html)

## Instructions

* Comment each line of code in the file with what you think is happening on that line.
