# Sign In (local storage)

## File

* [`2-student-do-signin-no-persistence`](../02-signin-nopersistence/Unsolved/2-student-do-signin-no-persistence.html)

## Instructions

* Using the solution provided to you in `2-student-do-signin-no-persistence-solution.html`, re-configure the application so that it utilizes localStorage.

* If your code worked it should save/display the last inputted user even if the tab is closed or if the page is closed and reopened.
