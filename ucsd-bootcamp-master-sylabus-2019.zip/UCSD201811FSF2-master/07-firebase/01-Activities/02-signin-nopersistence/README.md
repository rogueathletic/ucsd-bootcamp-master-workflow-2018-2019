# Sign In (no persistence)

## File

* [`2-student-do-signin-no-persistence`](Unsolved/2-student-do-signin-no-persistence.html)

## Instructions

* Using the `2-student-do-signin-no-persistence` as a starting point, fill in the JavaScript code necessary to make the page "save user inputs" and then re-display them on the second card(most recent member).

* **NOTE:** Don't worry about using client-side saving just yet. Just focus on getting the text inside the inputs and then displaying them via html in the second card.
