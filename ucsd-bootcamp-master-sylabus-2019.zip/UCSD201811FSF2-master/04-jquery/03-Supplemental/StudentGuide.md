## Unit 4 - Intro to jQuery



### Key Activities

* JSDrinkList
* jQueryDrinkList
* SandwichClick
* LotteryGenerator
* Captain Planet Game
* Crystal Collector Basic

### Helpful Links

* [JavaScript and jQuery](http://www.amazon.com/JavaScript-JQuery-Interactive-Front-End-Development/dp/1118531647/ref=sr_1_1?s=books&ie=UTF8&qid=1460751938&sr=1-1)
* [What You Should Know About JavaScript Scope](https://spin.atomicobject.com/2014/10/20/javascript-scope-closures/)

### Additional Course Resources

* [Curriculum Resources](https://github.com/coding-boot-camp/curriculum-resources)
