### File

* [`captain-planet-game`](Unsolved/captain-planet-game.html)

### Instructions

* Look at the jQuery API Docs [(https://api.jquery.com/)](https://api.jquery.com/) and add a button of your own that gives Captain Planet a new power.

* Examples:
  * Click to… Stretch Captain Planet!
  * Click to… Trigger a maniacal laugh!
  * Click to… Create clones of Captain Planet!
  * Click to… Create fire or water (hint: images)!

* Slack out a screenshot of the working example.
