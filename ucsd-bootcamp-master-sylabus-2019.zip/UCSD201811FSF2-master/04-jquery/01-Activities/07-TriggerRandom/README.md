### File

* [`trigger-random-unsolved`](Unsolved/trigger-random-unsolved.html)

### Instructions

* Add in the missing code such that clicking the big blue button triggers a random number (between 1 and 1000) to be selected and prominently displayed in the random-number div.

  * **HINT:** None. You got this.
