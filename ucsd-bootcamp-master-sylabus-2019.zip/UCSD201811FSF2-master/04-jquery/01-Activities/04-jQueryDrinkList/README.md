### File

* [`jquery-drink-list-unsolved`](Unsolved/jquery-drinklist-unsolved.html)

### Instructions

* Re-factor (re-write) your previous drinkList code from earlier, but this time use jQuery to complete all of the same tasks.

* Your final code should NOT have any of the following methods: `createElement`, `textContent`, or `appendChild`.

* **HINT:** Don’t forget to “incorporate” jQuery before you begin.

* **BONUS:** Instead of using a `for` loop, try searching about the use of the jQuery `.each` method.
