# This Example

## File

* [`this-unsolved`](Unsolved/this-unsolved.html)

## Instructions

* Using the comments in the guide answer each of the questions asked in the file.

* Focus your attention on trying to wrap your mind around the concept of "this" and the unique role it can play in code.

* Then try to explain to your partner how "this" works, focus on the first three examples.
