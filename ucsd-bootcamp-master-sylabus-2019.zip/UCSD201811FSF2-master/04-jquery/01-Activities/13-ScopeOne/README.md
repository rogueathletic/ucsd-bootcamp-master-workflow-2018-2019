### File

[`lexical-scope-1-unsolved`](Unsolved/lexical-scope-1-unsolved.html)

### Instructions

* Take a few moments dissecting what I just said.

* Look at the file above, and explain to the person next to you what is meant by:

  * The terms parent function and child function

  * The concept that child functions can access parent variables, but not vice versa.

* Be prepared to share!
