### File

* [`lexical-scope-2-unsolved`](Unsolved/lexical-scope-2-unsolved.html)

### Instructions

* Take a few moments to dissect the code in the file above.

* Try to predict what will be printed in each of the examples.

* Be prepared to share!

* **NOTE:** Pay attention to the unusual use of the keyword: `this`
