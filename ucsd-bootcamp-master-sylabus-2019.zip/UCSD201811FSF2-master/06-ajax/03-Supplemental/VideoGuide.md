## Complete video guide

### Key activities

#### GIPHY API

We go over simple API calls and the basics of AJAX requests.
[Watch the Video!](https://www.youtube.com/watch?v=Kp7Xy2LScLM)

#### Button Triggered AJAX

We go over how to attach ajax calls to the clicking of an HTML button.
[Watch the Video!](https://www.youtube.com/watch?v=K1JDUkF94cs)

#### Dynamic Elements

We go over how to dynamically create HTML elements using jQuery, AJAX, and button clicks.
[Watch the Video!](https://www.youtube.com/watch?v=UVBmX4cZkHY)

### NYT Article Solution

We go over how to create the full NYT Articles Search application from beginning to end.
[Watch the Video!](https://www.youtube.com/watch?v=PDD8NV3sbZo)

#### Stopwatch Fun

Learn how to use built in JavaScript functions: setInterval and clearInterval!
[Watch the Video!](https://www.youtube.com/watch?v=EGhF4iJSnl0)

#### (Interview) - Fizz Buzz

Learn how to completer a common technical review challenge: Fizz Buzz!
[Watch the Video!](https://www.youtube.com/watch?v=oTart7fFefI) 
