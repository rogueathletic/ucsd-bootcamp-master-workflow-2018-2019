## Unit 6 - Introduction to APIs and AJAX

### Homework Activities

* [Giphy Viewer](../../../01-Class-Content/06-ajax/02-Homework/Instructions/homework.md)
* [Homework Demo](https://youtu.be/BqreERTLjgQ)

### Key Activities

* [6.1 - Button Triggered AJAX]()
* [6.1 - Giphy API]()
* [6.2 - Working OMDb Movie App]()
* [6.3 - Dynamic Elements]()
* [6.3 - Pausing Gifs]()
* [6.3 - NYT Search Application]()

### Helpful Links

* [AJAX Documentation](http://api.jquery.com/jquery.ajax/)
* [Giphy API](https://developers.giphy.com/docs/)
* [OMDb API](http://www.omdbapi.com/)
* [Open Weather Map API](http://openweathermap.org/api)
* [New York Times Article API](http://developer.nytimes.com/docs/read/article_search_api_v2)
* [NYT Activity Video Walkthrough (Highly Recommended)](https://youtu.be/RQTVw6XJAac?list=PLgJ8UgkiorCnCFzNp0dP0zJyeFAgstYTj)

### Additional Course Resources

* [Curriculum Resources](https://github.com/coding-boot-camp/curriculum-resources)
