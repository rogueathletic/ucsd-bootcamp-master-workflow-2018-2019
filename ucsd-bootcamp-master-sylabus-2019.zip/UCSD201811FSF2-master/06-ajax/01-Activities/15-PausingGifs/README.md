# Pausing Gifs

## File

* [`pausing-gifs`](Unsolved/pausing-gifs.html)

## Instructions

* Using the comments provided in the code, add in the code necessary to provide stop/start animation to your application.
