# Working Movie App

## File

* [`working-movie-app-easier`](Unsolved/working-movie-app-easier.html) or [`working-movie-app-harder`](Unsolved/working-movie-app-harder.html)

## Instructions

* Using either version of the starter code provided to you, complete the application so that various snippets of information about your movie are displayed underneath. As a suggestion, display at least each of the following:

  * Movie Poster

  * Rating

  * Release Date

  * Plot
