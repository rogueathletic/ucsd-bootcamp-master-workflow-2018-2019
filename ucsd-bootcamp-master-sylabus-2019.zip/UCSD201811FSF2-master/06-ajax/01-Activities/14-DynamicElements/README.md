# Dynamic Elements

## File

* [`dynamic-elements`](Unsolved/dynamic-elements.html)

## Instructions

* Using the comments in the code as a guide -- replicate the functionality shown to you.

* Your completed application should trigger gifs to appear related to the animal making the sound listed in the button.
