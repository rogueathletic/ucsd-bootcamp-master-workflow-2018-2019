# Customer Object

## File

* [`customer-object`](Unsolved/customer-object.html)

## Instructions

* Using the instructions shown in the comments, create `console.log` statements that parse out the requested information.

* Help those around you if you finish early.
