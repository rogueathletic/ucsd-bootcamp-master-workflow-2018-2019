# Log Movie Name

## File

* [`click-json`](Unsolved/click-json.html)

## Instructions

* Using the Starter code provided, create the missing code snippets inside the `displayMovieInfo()` function necessary to display JSON data about each movie.

* **HINT:** You should use HTML `data-` attributes.
