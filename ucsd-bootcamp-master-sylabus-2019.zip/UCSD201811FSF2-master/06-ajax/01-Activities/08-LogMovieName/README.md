# Log Movie Name

## File

* [`log-movie-name`](Unsolved/log-movie-name.html)

## Instructions

* Using the starter code provided, create the missing code snippets inside the `alertMovieName` function necessary to capture the movie name for both the original and new buttons.

* **HINT:** You should use HTML `data-` attributes.
