
## JavaScript Workbook

If you're new to coding, you may be feeling a bit overwhelmed. It can be tempting to spend lots of time outside class watching videos and reviewing lectures, but you _must spend actual time coding_.

We've put together a workbook for you to practice things you've learned this unit. It's quite long, but you don't need to read it front-to-back and you shouldn't do it all in one setting.

Instead, reference this throughout the class. When you get stuck on homework, come back to small chunks of the workbook:

[JavaScript Workbook](https://javascript-workbook.netlify.com/)
