### JavaScript Workbook

* [JavaScript Workbook](https://javascript-workbook.netlify.com/)

### Helpful Links

* [Eloquent JavaScript](http://eloquentjavascript.net/)
* [JavaScript and jQuery](http://www.amazon.com/JavaScript-JQuery-Interactive-Front-End-Development/dp/1118531647/ref=sr_1_1?s=books&ie=UTF8&qid=1460751938&sr=1-1)

### Additional Course Resources

* [Curriculum Resources](https://github.com/coding-boot-camp/curriculum-resources)
