### File

* [`js-dissect`](js-dissect.html)

### Instructions

* Open the file in Chrome, and observe what happens.

* With a partner, try to explain how the code connects to the events that happen on the page.

* **NOTE:** We haven't covered JavaScript before, but a big part of being a developer is learning on the fly!
