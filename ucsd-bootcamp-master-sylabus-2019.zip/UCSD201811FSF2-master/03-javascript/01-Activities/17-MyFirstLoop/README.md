### File

* [`my-first-loop.html`](my-first-loop.html)

### Instructions

* With a partner, spend a few moments trying to dissect the code in the file.

* Try to explain to one another what is happening with each line of code.

* Feel free to do research if you are stumped. As a hint, look into the phrase "for loop."
