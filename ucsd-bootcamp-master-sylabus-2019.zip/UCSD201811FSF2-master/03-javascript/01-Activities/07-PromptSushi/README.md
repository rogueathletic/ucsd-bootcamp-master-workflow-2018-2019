### File

* [`prompt-sushi`](Unsolved/prompt-sushi.html)

### Instructions

* Write JavaScript code that does the following:
  * Using a confirm, ask the user, "Do you like \_?" Store their response in a variable.
  * Using a prompt, ask the user, "What kind of \_ do you like?" Store their response in a variable.
  * Alert both variables to the screen.
